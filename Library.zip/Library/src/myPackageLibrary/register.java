package myPackageLibrary;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


public class register {
    private String fullname;
    private String username;
    private String password;
    private String phone;
    private String email;
    
public register(){
    }    
    
public register(String fullname, String username, String password, String phone, String email) {
        this.fullname = fullname;
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.email = email;
    }
    public String getFullname() {
        return fullname;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
    public void save(){
        try{
            DocumentBuilderFactory  dbf=DocumentBuilderFactory.newInstance();
            DocumentBuilder db=dbf.newDocumentBuilder();
            File file=new File("F:\\Mahboubeh khanom gole golab\\backend\\Library\\src\\xml\\register.xml");
            Document d=db.parse(file);
            d.normalize();
            
            Element root = d.getDocumentElement();
            
            Element nodeElement = d.createElement("User");
            root.appendChild(nodeElement);
            
            Element p1 = d.createElement("FullName");
            Element p2 = d.createElement("Username");
            Element p3 = d.createElement("Password");
            Element p4 = d.createElement("Phone");
            Element p5 = d.createElement("Email");
            
            p1.appendChild(d.createTextNode(this.fullname));
            p2.appendChild(d.createTextNode(this.username));
            p3.appendChild(d.createTextNode(this.password));
            p4.appendChild(d.createTextNode(this.phone));
            p5.appendChild(d.createTextNode(this.email));
            
            nodeElement.appendChild(p1);
            nodeElement.appendChild(p2);
            nodeElement.appendChild(p3);
            nodeElement.appendChild(p4);
            nodeElement.appendChild(p5);
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(d);
            StreamResult result = new StreamResult(file);
            t.transform(source, result);
            
        }
        catch(Exception ex){
        } 
    }
}


