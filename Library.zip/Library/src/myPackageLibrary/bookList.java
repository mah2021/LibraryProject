
package myPackageLibrary;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class bookList {
    private String bookName;
    private String auther;
    private String genre;
    private Integer number;
  public bookList(){
      
  }
    public bookList(String bookName, String auther, String genre, Integer number) {
        this.bookName = bookName;
        this.auther = auther;
        this.genre = genre;
        this.number = number;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuther() {
        return auther;
    }

    public void setAuther(String auther) {
        this.auther = auther;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
    public void saveBook(){
        try{
            DocumentBuilderFactory  dbf=DocumentBuilderFactory.newInstance();
            DocumentBuilder db=dbf.newDocumentBuilder();
            File file=new File("F:\\Mahboubeh khanom gole golab\\backend\\Library\\src\\xml\\bookList.xml");
            Document d=db.parse(file);
            d.normalize();
            
            Element root = d.getDocumentElement();
            
            Element nodeElement = d.createElement("Book");
            root.appendChild(nodeElement);
            
            Element p1 = d.createElement("BookName");
            Element p2 = d.createElement("Auther");
            Element p3 = d.createElement("Genre");
            Element p4 = d.createElement("Number");
            
            
            p1.appendChild(d.createTextNode(this.bookName));
            p2.appendChild(d.createTextNode(this.auther));
            p3.appendChild(d.createTextNode(this.genre));
            p4.appendChild(d.createTextNode(this.number.toString()));
            
            
            nodeElement.appendChild(p1);
            nodeElement.appendChild(p2);
            nodeElement.appendChild(p3);
            nodeElement.appendChild(p4);
           
            
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(d);
            StreamResult result = new StreamResult(file);
            t.transform(source, result);
            
        }
        catch(Exception ex){
        } 
    }
}
